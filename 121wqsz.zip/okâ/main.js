function signup(e) {
    event.preventDefault(); // Dùng đúng biến e

    var role = document.getElementById("role").value;

    let user;
    let email;

    if (role === "student") {
        var name = document.getElementById("s-fname").value;
        var date = document.getElementById("s-date").value;
        var gender = document.getElementById("s-gender").value;
        var grade = document.getElementById("s-grade").value;
        var class1 = document.getElementById("s-class").value;
        var pass = document.getElementById("s-pass").value;
        var phone = document.getElementById("s-phone").value;
        email = document.getElementById("s-email").value;

        user = {
            role: "student",
            name: name,
            email: email,
            pass: pass
        };
    } else if (role === "teacher") {
        var name = document.getElementById("t-fname").value;
        var date = document.getElementById("t-date").value;
        var gender = document.getElementById("t-gender").value;
        var subject = document.getElementById("t-subject").value;
        var pass = document.getElementById("t-pass").value;
        var phone = document.getElementById("t-phone").value;
        email = document.getElementById("t-email").value;

        var confirm = document.getElementById("t-confirm").checked;

        if (!confirm) {
            alert("Bạn cần xác nhận là giáo viên của trường.");
            return;
        }

        user = {
            role: "teacher",
            name: name,
            email: email,
            pass: pass
        };
    } else {
        alert("Vui lòng chọn vai trò.");
        return;
    }

    // Lưu vào localStorage
    var json = JSON.stringify(user);
    localStorage.setItem(email, json);

    alert("Đăng ký thành công!");
    window.location.href = "log.html";
}

function toggleRoleForm() {
    var role = document.getElementById("role").value;
    var studentForm = document.getElementById("studentForm");
    var teacherForm = document.getElementById("teacherForm");

    studentForm.classList.add("hidden");
    teacherForm.classList.add("hidden");

    if (role === "student") {
        studentForm.classList.remove("hidden");
    } else if (role === "teacher") {
        teacherForm.classList.remove("hidden");
    }
}
function login(e) {
    event.preventDefault(); // Sử dụng đúng biến e

    var email = document.getElementById("email").value;
    var pass = document.getElementById("pass").value;

    if (!email || !pass ) {
        alert('Vui lòng nhập đầy đủ email và mật khẩu') ; 
        return;
    }

    var user = localStorage.getItem(email);

    if (!user) {
        alert('Tài khoản không tồn tại hoặc email sai.');
        return;
    }

    var data = JSON.parse(user);

    if (email === data.email && pass === data.pass ) {
        alert('Đăng nhập thành công');

        if (data.role === "student") {
            window.location.href = "indexhs.html";
        } else if (data.role === "teacher") {
            window.location.href = "indexgv.html";
        }
    } else {
        alert('Đăng nhập thất bại. Kiểm tra lại email, mật khẩu hoặc vai trò.');
    }
}


// ⚠️ Đặt đúng sự kiện DOMContentLoaded và addEventListener bên trong
document.addEventListener("DOMContentLoaded", function () {
    var roleSelect = document.getElementById("role");
    if (roleSelect) {
        roleSelect.addEventListener("change", toggleRoleForm);
        toggleRoleForm(); // Gọi 1 lần để hiển thị form đúng ngay khi load
    }
});




function openPopup() {
    let popup = document.getElementById('popup');
    popup.style.display = 'block';
    setTimeout(() => {
        popup.style.opacity = '1';
        popup.style.transform = 'translate(-50%, -50%) scale(1)';
    }, 10);
}
function closePopup() {
    let popup = document.getElementById('popup');
    popup.style.opacity = '0';
    popup.style.transform = 'translate(-50%, -50%) scale(0.8)';
    setTimeout(() => {
        popup.style.display = 'none';
    }, 300);
}